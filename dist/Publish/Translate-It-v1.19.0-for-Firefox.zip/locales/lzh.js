const e="Chinese (Literary)",a="文言文",s="Classical Chinese",t="lzh",i={name:e,nativeName:"文言文",promptName:s,code:"lzh"};export{t as code,i as default,e as name,a as nativeName,s as promptName};
